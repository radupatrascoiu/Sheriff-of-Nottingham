package com.tema1.players;

public enum Function { Sheriff, Trader }
